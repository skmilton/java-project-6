
package com.milton.test;

import com.milton.connection.DbConnection;
import com.milton.service.CommonServiceAdapter;
import com.milton.serviceImpl.CategoryServiceImpl;
import com.milton.serviceImpl.DailySalesServiceImpl;
import com.milton.serviceImpl.ProductServiceImpl;
import com.milton.serviceImpl.PurchaseServiceImpl;
import com.milton.serviceImpl.SalesServiceImpl;
import com.milton.serviceImpl.SummaryServiceImpl;
import com.milton.serviceImpl.UserServiceImpl;
import java.sql.Connection;

public class Test {
     public static void main(String[] args) {
       Connection con=DbConnection.getInstance();
        CommonServiceAdapter cat = new CategoryServiceImpl();
         CommonServiceAdapter product = new ProductServiceImpl();

         CommonServiceAdapter purcahase = new PurchaseServiceImpl();
         CommonServiceAdapter sales = new SalesServiceImpl();
         CommonServiceAdapter summery = new SummaryServiceImpl();
         CommonServiceAdapter dailysales = new DailySalesServiceImpl();
         CommonServiceAdapter user = new UserServiceImpl();

//        cat.createTable();
//        product.createTable();
//        purcahase.createTable();
//        sales.createTable();
//        summery.createTable();
//        dailysales.createTable();
        user.createTable();
//    
}
}